package com.example.demo.dao;

import com.example.demo.model.department;

public interface DepartmentDAO {
    void insertDepartment(department department);
}
