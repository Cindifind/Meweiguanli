package com.example.demo.dao;

import com.example.demo.model.AddUser;
public interface UsersDAO {
    void insertUser(AddUser user);
}
